#include<stdio.h>
int main()
{
	printf("Workshop 1 Part-2\n=================\n\n");
	printf("Using tab specifiers...\n");
	printf("	Tab-1	Tab-2	Tab-3\n	-----	=====	-----\n\n");
	printf("\\ this is a back-slash character!\n");
	printf("%% this is a percent sign character!\n");
	printf("\" this is a double-quote character!\n");
	printf("\nMy favourite quotes are:\n");
	printf("1.	\"Skill is only developed by hours and hours of work.\"\n						-Usain Bolt\n\n");
	printf("2.	\"It\'s not about having time. It\'s about making time.\"\n						-unknown\n\n");
	printf("3.	\"All of us do not have equal talent. But, all of us\n	have an equal opportunity to develop our talents.\"\n						-A.P.J. Abdul Kalam\n");

	return 0;
}