// Copy the below commented "header" section to all your source code files!

/*/////////////////////////////////////////////////////////////////////////
                        Assignment 1 - Milestone 1
Full Name  : Kavya Bhvainkumar Shah
Student ID#: 140055229
Email      : kbshah6
Section    : ZBB

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include "core.h"

// As demonstrated in the course notes: 
// https://intro2c.sdds.ca/D-Modularity/input-functions#clearing-the-buffer
// Clear the standard input buffer
void clearInputBuffer(void)
{
    // Discard all remaining char's from the standard input buffer:
    while (getchar() != '\n')
    {
        ; // do nothing!
    }
}

// Wait for user to input the "enter" key to continue
void suspend(void)
{
    printf("<ENTER> to continue...");
    clearInputBuffer();
    putchar('\n');
}


// inputInt
int inputInt(void) {

    char new_line = ' ';
    int value;

    do {
        scanf("%d%c", &value, &new_line);

        if (new_line != '\n') {
            clearInputBuffer();
            printf("Error! Input a whole number: ");
        }



    } while (new_line != '\n');

    return value;
}

//inputIntPositive
int inputIntPositive(void) {

    int value;
    char new_line = ' ';

    do {
        scanf("%d%c", &value, &new_line);

        if (new_line != '\n') {
            clearInputBuffer();
            printf("Error! Input a whole number: ");
        }

        if (value <= 0) {
            printf("ERROR! Value must be > 0: ");
        }
    } while (value <= 0);

    return value;

}


// inputIntRange
int inputIntRange(int lower_Bound, int upper_Bound) {
    char ch = ' ';
    int a;

    do {
        scanf("%d%c", &a, &ch);

        if (ch != '\n') {
            clearInputBuffer();
            printf("Error! Input a whole number: ");
        }

        else if (!(a <= upper_Bound && a >= lower_Bound)) {
            printf("ERROR! Value must be between -3 and 11 inclusive: ");
        }
    } while (!(a <= upper_Bound && a >= lower_Bound));

    return a;
}

// inputCharOption
char inputCharOption(char* string)
{
    int m, n = 0;
    char input;

    do {
        scanf(" %c", &input);

        for (m = 0; string[m] != '\0'; m++) {
            if (input == string[m]) {
                n++;
            }
        }

        if (n == 0) {
            printf("ERROR: Character must be one of [%s]: ", string);
        }
    } while (n == 0);

    clearInputBuffer();
    return input;

}

//inputCString
void inputCString(char* str, int min_num, int max_num) {
    int flag = 1;
    char character = 'a';

    while (flag) {
        int length = 0;
        // Takes a string as input until it sees a newline character
        while (character != '\n' && length <= max_num) {
            character = getchar();
            str[length] = character;
            length++;
        };

        // If the string is less than or equal to the maxChars we will just add '\0' to the end to mark the end of the string
        if (character == '\n' && length <= (max_num + 1)) {
            length--;
            str[length] = '\0';
        }
        // If length is more than maxChar, we will add '\0' to the end and ignore the extra characters. We will also remove the extra characters from the buffer.
        else {
            str[max_num] = '\0';
            clearInputBuffer();
        }

        if (min_num == max_num && length != min_num) {
            printf("ERROR: String length must be exactly %d chars: ", min_num);
            character = 'a';
        }
        else if (length < min_num || length > max_num) {
            if (length > max_num) {
                printf("ERROR: String length must be no more than %d chars: ", max_num);
                character = 'a';
            }
            else if (length < min_num) {
                printf("ERROR: String length must be between %d and %d chars: ", min_num, max_num);
                character = 'a';
            }
        }
        else {
            flag = 0;
        }
    }
}


void displayFormattedPhone(const char* str) {
    int i;

    if (str == NULL) {
        printf("(___)___-____");
        return;
    }

    for (i = 0; i < 10; i++) {
        if (str[i] < '0' || str[i] > '9') {
            printf("(___)___-____");
            return;
        }
    }

    if (str[i] != '\0') {
        printf("(___)___-____");
        return;
    }

    printf("(%c%c%c)%c%c%c-%c%c%c%c", str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7], str[8], str[9]);
}
