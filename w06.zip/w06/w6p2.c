/*/////////////////////////////////////////////////////////////////////////
						  Workshop - #6 (P1)
Full Name  : Kavya Bhavinkumar Shah
Student ID#: 140055229
Email      : kbshah6@myseneca.ca
Section    : ZBB
Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#define MIN_INCOME 500.00
#define MAX_INCOME 400000.00
#define MAX_ITEMS 10
#define MIN_COST 100.00

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void) {
    double monthly_income;
    int items;

    double cost_of_items[MAX_ITEMS];
    int importance[MAX_ITEMS];
    char finance[MAX_ITEMS];
    int i; 

    double total_cost = 0.0;

    int selection_of_items,m=0,n;
    int priority_of_item;
    double filtered_cost = 0.0;

    printf("+--------------------------+\n");
    printf("+   Wish List Forecaster   |\n");
    printf("+--------------------------+\n");

    // Prompt user to enter the monthly income
    do { 
        printf("\nEnter your monthly NET income: $");
        scanf("%lf%*c", &monthly_income);

        if (monthly_income < MIN_INCOME) {
            printf("ERROR: You must have a consistent monthly income of at least $500.00\n");
        }

        if (monthly_income > MAX_INCOME) {
            printf("ERROR: Liar! I'll believe you if you enter a value no more than $400000.00\n");
        }

    } while (monthly_income < MIN_INCOME || monthly_income > MAX_INCOME);

    // Prompt user to enter the number of wish list items
    do {
        printf("\nHow many wish list items do you want to forecast?: ");
        scanf("%d%*c", &items);

        if (items < 1 || items > MAX_ITEMS) {
            printf("ERROR: List is restricted to between 1 and 10 items.\n");
        }

    } while (items < 1 || items > MAX_ITEMS);

    // Item Details
    for (i = 0; i < items; i++) {
        printf("\nItem-%d Details:\n", i + 1);

        // Cost
        do {
            printf("   Item cost: $");
            scanf("%lf%*c", &cost_of_items[i]);

            if (cost_of_items[i] < MIN_COST) {
                printf("      ERROR: Cost must be at least $100.00\n");
            }

        } while (cost_of_items[i] < MIN_COST);

        // Importance
        do {
            printf("   How important is it to you? [1=must have, 2=important, 3=want]: ");
            scanf("%d%*c", &importance[i]);

            if (importance[i] < 1 || importance[i] > 3) {
                printf("      ERROR: Value must be between 1 and 3\n");
            }

        } while (importance[i] < 1 || importance[i] > 3);

        // Finance 
        do {
            printf("   Does this item have financing options? [y/n]: ");
            scanf("%c%*c", &finance[i]);

            if (finance[i] != 'y' && finance[i] != 'n') {
                printf("      ERROR: Must be a lowercase 'y' or 'n'\n");
            }
        } while (finance[i] != 'y' && finance[i] != 'n');

    }

    //Table contents
    printf("\n");
    printf("Item Priority Financed        Cost\n");
    printf("---- -------- -------- -----------\n");

    for (i = 0; i < items; i++)
    {
        printf("%3d  %5d    %5c    %11.2lf\n", i + 1, importance[i], finance[i], cost_of_items[i]);
        total_cost += cost_of_items[i];
    }

    printf("---- -------- -------- -----------\n");
    printf("                      $ %.2lf\n\n", total_cost); 

    // Forecast by priority
    do {
        printf("How do you want to forecast your wish list?\n");
        printf(" 1. All items (no filter)\n");
        printf(" 2. By priority\n");
        printf(" 0. Quit/Exit\n");
        printf("Selection: ");
        scanf("%d%*c", &selection_of_items);

        if (selection_of_items == 1) {
            printf("\n====================================================\n");
            printf("Filter:   All items\n");
            printf("Amount:   $%.2lf\n", total_cost);
            int forecast_years = (int)(total_cost / (12.0 * monthly_income));
            int forecast_months = (int)((total_cost / monthly_income) - (12 * forecast_years));
            double remaining_funds = total_cost - (forecast_years * 12.0 * monthly_income + forecast_months * monthly_income);
            if (remaining_funds > 0)
                forecast_months++;
            printf("Forecast: %d years, %d months\n", forecast_years, forecast_months);
            m = 0;
            for (n = 0; n < items; n++)
            {
                if (finance[n] == 'y') {
                    m += 1;
                }
            }
            if (m != 0) {
                printf("NOTE: Financing options are available on some items.\n");
                printf("      You can likely reduce the estimated months.\n");
                
            }
            printf("====================================================\n\n");
            
        }

        else if (selection_of_items == 2) {
            do {
                printf("\nWhat priority do you want to filter by? [1-3]: ");
                scanf("%d%*c", &priority_of_item);

                if (priority_of_item < 1 || priority_of_item > 3) {
                    printf("      ERROR: Value must be between 1 and 3\n");
                }

            } while (priority_of_item < 1 || priority_of_item > 3);

            // Calculate filtered cost
            filtered_cost = 0.0;

            for (i = 0; i < items; i++) {
                if (importance[i] == priority_of_item) {
                    filtered_cost += cost_of_items[i];
                }
            }

            printf("\n====================================================\n");
            printf("Filter:   by priority (%d)\n", priority_of_item);
            printf("Amount:   $%.2lf\n", filtered_cost);
            int forecast_years = (int)(filtered_cost / (12.0 * monthly_income));
            int forecast_months = (int)((filtered_cost / monthly_income) - (12 * forecast_years));
            double remaining_funds = filtered_cost - (forecast_years * 12.0 * monthly_income + forecast_months * monthly_income);
            if (remaining_funds > 0)
                forecast_months++;
            printf("Forecast: %d years, %d months\n", forecast_years, forecast_months);
            
            m = 0;
            for (n = 0; n < items; n++)
            {
                if (finance[n] == 'y' && importance[n] == priority_of_item) {
                    m += 1;
                }
            }
            if (m != 0) {
                printf("NOTE: Financing options are available on some items.\n");
                printf("      You can likely reduce the estimated months.\n");

            }
            printf("====================================================\n\n");
        }
        else if (selection_of_items != 0) {
            printf("\nERROR: Invalid menu selection.\n\n");
        }
    } while (selection_of_items != 0);

    printf("\nBest of luck in all your future endeavours!\n");

    return 0;
}
