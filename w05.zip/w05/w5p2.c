/*/////////////////////////////////////////////////////////////////////////
						  Workshop - #5 (P1)
Full Name  : Kavya Bhavinkumar Shah
Student ID#: 140055229
Email      : kbshah6@myseneca.ca
Section    : ZBB
Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#include <stdio.h>

#define MIN_YEAR 2012
#define MAX_YEAR 2022
#define JAN 1
#define DEC 12
#define LOG_DAYS 3

int main() {
    int year, month, day;
    int valid_year = 1, valid_month = 1; // Valid Flag for year/month 
    double rate_in_morning = 0, rate_in_evening = 0;
    double total_morning = 0, total_evening = 0;
    printf("General Well-being Log\n");
    printf("======================\n");

    // Prompt and verify the year and month entries.
    do {
        printf("Set the year and month for the well-being log (YYYY MM): ");
        scanf("%d%*c%d%*c", &year, &month);

        valid_year = (year >= MIN_YEAR && year <= MAX_YEAR);
        valid_month = (month >= JAN && month <= DEC);

        if (!valid_year && !valid_month) {
            printf("   ERROR: The year must be between %d and %d inclusive\n", MIN_YEAR, MAX_YEAR);
            printf("   ERROR: Jan.(%d) - Dec.(%d)\n", JAN, DEC);
        }
        else if (!valid_year) {
            printf("   ERROR: The year must be between %d and %d inclusive\n", MIN_YEAR, MAX_YEAR);
        }
        else if (!valid_month) {
            printf("   ERROR: Jan.(%d) - Dec.(%d)\n", JAN, DEC);
        }
    } while (!valid_year || !valid_month);

    printf("\n*** Log date set! ***\n");

    // Loop for each day to enter ratings.
    for (day = 1; day <= LOG_DAYS; day++) {
        printf("\n");
        printf("%04d-", year);

        // Printing the abbreviated month depending on the provided input.
        switch (month) {
        case 1:
            printf("JAN");
            break;
        case 2:
            printf("FEB");
            break;
        case 3:
            printf("MAR");
            break;
        case 4:
            printf("APR");
            break;
        case 5:
            printf("MAY");
            break;
        case 6:
            printf("JUN");
            break;
        case 7:
            printf("JUL");
            break;
        case 8:
            printf("AUG");
            break;
        case 9:
            printf("SEP");
            break;
        case 10:
            printf("OCT");
            break;
        case 11:
            printf("NOV");
            break;
        case 12:
            printf("DEC");
            break;
        default:
            printf("Invalid!");
            break;
        }

        printf("-%02d\n", day);

        // Prompt and confirm the rating for the morning.
        do {
            printf("   Morning rating (0.0-5.0): ");
            scanf("%lf", &rate_in_morning);

            if (rate_in_morning < 0.0 || rate_in_morning > 5.0) {
                printf("      ERROR: Rating must be between 0.0 and 5.0 inclusive!\n");
            }
        } while (rate_in_morning < 0.0 || rate_in_morning > 5.0);

        // Verify the evening's rating by using prompt.
        do {
            printf("   Evening rating (0.0-5.0): ");
            scanf("%lf", &rate_in_evening);

            if (rate_in_evening < 0.0 || rate_in_evening > 5.0) {
                printf("      ERROR: Rating must be between 0.0 and 5.0 inclusive!\n");
            }
        } while (rate_in_evening < 0.0 || rate_in_evening > 5.0);

        // Gather both the morning and evening ratings.
        total_evening += rate_in_evening;
        total_morning += rate_in_morning;
    }

    // Show an overview of the evaluations.
    printf("\nSummary\n");
    printf("=======\n");
    printf("Morning total rating: %.3lf\n", total_morning);
    printf("Evening total rating:  %.3lf\n", total_evening);
    printf("----------------------------\n");
    printf("Overall total rating: %.3lf\n\n", total_morning + total_evening);
    printf("Average morning rating:  %.1lf\n", total_morning / LOG_DAYS);
    printf("Average evening rating:  %.1lf\n", total_evening / LOG_DAYS);
    printf("----------------------------\n");
    printf("Average overall rating:  %.1lf\n", (total_morning + total_evening) / (2 * LOG_DAYS));

    return 0;
}
