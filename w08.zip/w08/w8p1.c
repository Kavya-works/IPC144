/*/////////////////////////////////////////////////////////////////////////
                          Workshop - #8 (P1)
Full Name  : Kavya Bhavinkumar Shah
Student ID#: 140055229
Email      : kbshah6@myseneca.ca
Section    : ZBB

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#define _CRT_SECURE_NO_WARNINGS


// System Libraries
#include<stdio.h>

// User Libraries
#include "w8p1.h"

// 1. Get user input of int type and validate for a positive non-zero number
//    (return the number while also assigning it to the pointer argument)
int getIntPositive(int *positive_int) {
	int value;
	int flag = 0;

	do {
		scanf("%d", &value);
		if (value <= 0)
			printf("ERROR: Enter a positive value: ");
		else
			flag = 1;
	} while (flag == 0);

	if (positive_int != NULL)
		*positive_int = value;
	
	return value;
}

// 2. Get user input of double type and validate for a positive non-zero number
//    (return the number while also assigning it to the pointer argument)
double getDoublePositive(double *positive_double) {
	double value;
	int flag = 0;

	do {
		scanf("%lf", &value);
		if (value <= 0)
			printf("ERROR: Enter a positive value: ");
		else
			flag = 1;
	} while (flag == 0);

	if (positive_double != NULL)
		*positive_double = value;

	return value;
}

// 3. Opening Message (include the number of products that need entering)
void openingMessage(const int number) {

	printf("Cat Food Cost Analysis\n");
	printf("======================\n");
	printf("\n");

	printf("Enter the details for %d dry food bags of product data for analysis.\n", maxProduct);
	printf("NOTE: A 'serving' is %dg\n", noOfGrams);
	printf("\n");
}

// 4. Get user input for the details of cat food product
	struct CatFoodInfo getCatFoodInfo(const int number) {

		int flag = 0;
		struct CatFoodInfo cfi;

		printf("Cat Food Product #%d\n", number + 1);
		printf("--------------------\n");
		flag = 0;

		// About - SKU
		printf("SKU           : ");
		flag = 0;
		do {
			scanf("%d", &cfi.sku);
			if (cfi.sku <= 0)
				printf("ERROR: Enter a positive value: ");
			else
				flag = 1;
		} while (flag == 0);

		// About - Price
		printf("PRICE         : $");
		flag = 0;
		do {
			scanf("%lf", &cfi.price);
			if (cfi.price <= 0)
				printf("ERROR: Enter a positive value: ");
			else
				flag = 1;
		} while (flag == 0);

		// About - Weight
		printf("WEIGHT (LBS)  : ");
		flag = 0;
		do {
			scanf("%lf", &cfi.weight);
			if (cfi.weight <= 0)
				printf("ERROR: Enter a positive value: ");
			else
				flag = 1;
		} while (flag == 0);

		// About - Calories
		printf("CALORIES/SERV.: ");
		flag = 0;
		do {
			scanf("%d", &cfi.calories);
			if (cfi.calories <= 0)
				printf("ERROR: Enter a positive value: ");
			else
				flag = 1;
		} while (flag == 0);

		printf("\n");

		return cfi;
	}

// 5. Display the formatted table header
void displayCatFoodHeader(void)
{
	printf("SKU         $Price    Bag-lbs Cal/Serv\n");
	printf("------- ---------- ---------- --------\n");
}

// 6. Display a formatted record of cat food data
void displayCatFoodData(int* sku, double* price, double weight, int calories)
{
	printf("%07d %10.2lf %10.1lf %8d\n", *sku, *price, weight, calories);
}

// 7. Logic entry point
void start(void)
{
	int a;
	struct CatFoodInfo cfi[maxProduct] = { {0} };

	openingMessage(maxProduct);

	for (a = 0; a < maxProduct; a++) {
		cfi[a] = getCatFoodInfo(a);
	}

	displayCatFoodHeader();

	for (a = 0; a < maxProduct; a++) {
		displayCatFoodData(&cfi[a].sku, &cfi[a].price, cfi[a].weight, cfi[a].calories);
	}

}
