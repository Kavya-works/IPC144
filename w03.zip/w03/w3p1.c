/*/////////////////////////////////////////////////////////////////////////
                          Workshop - #3 (P1)
Full Name  : Kavya Bhvainkumar Shah
Student ID#: 140055229

Email      : kbshah6@myseneca.ca
Section    : ZBB

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#include <stdio.h>

int main(void)
{
    // You must use this variable in #3 data analysis section!
    const double testValue = 330.99;
    int ID_1=111, ID_2=222, ID_3=111;
    const  char tax_1 = 'Y', tax_2 = 'N' , tax_3 = 'N';
    double p_1=111.4900, p_2=222.9900, p_3=334.4900;
    double avg = (p_1 + p_2 + p_3)/3;
    double p_4 = p_1 + p_2;


    printf("Product Information");
    printf("\n===================\n");

    printf("Product-1 (ID:%d)\n", ID_1);
    printf("  Taxed: %c\n", tax_1);
    printf("  Price: $%.4lf\n\n", p_1);

    printf("Product-2 (ID:%d)\n", ID_2);
    printf("  Taxed: %c\n", tax_2);
    printf("  Price: $%.4lf\n\n", p_2);

    printf("Product-3 (ID:%d)\n", ID_3);
    printf("  Taxed: %c\n", tax_3);
    printf("  Price: $%.4lf\n", p_3);

    printf("\nThe average of all prices is: $%.4lf\n\n",avg);

    printf("About Relational and Logical Expressions!\n"
        "========================================\n"
        "1. These expressions evaluate to TRUE or FALSE\n"
        "2. FALSE: is always represented by integer value 0\n"
        "3. TRUE : is represented by any integer value other than 0\n\n");

    printf("Some Data Analysis...\n"
        "=====================\n");

    printf("1. Is product 1 taxable? -> %d\n", tax_1 == 'Y');
    printf("\n2. Are products 2 and 3 both NOT taxable (N)? -> %d\n", tax_2 == 'N' && tax_3 == 'N');
    printf("\n3. Is product 3 less than testValue ($330.99)? -> %d\n", p_3 < testValue);
    printf("\n4. Is the price of product 3 more than both product 1 and 2 combined? -> %d\n", p_3 > p_4);
    printf("\n5. Is the price of product 1 equal to or more than the price difference\n   of product 3 LESS product 2? ->  %d (price difference: $%.2lf)\n", p_1 >= p_3 - p_2 , p_3-p_2);
    printf("\n6. Is the price of product 2 equal to or more than the average price? -> %d\n", p_2 >= avg);
    printf("\n7. Based on product ID, product 1 is unique -> %d\n", (ID_3 != ID_1) && (ID_2 != ID_1));
    printf("\n8. Based on product ID, product 2 is unique -> %d\n", (ID_3 != ID_2) && (ID_1 != ID_2));
    printf("\n9. Based on product ID, product 3 is unique -> %d\n", (ID_1 != ID_3) && (ID_2 != ID_3));

    return 0;
}