/*/////////////////////////////////////////////////////////////////////////
                          Workshop - #3 (P2)
Full Name  : Kavya Bhavinkumar Shah
Student ID#: 140055229
Email      : kbshah6@myseneca.ca
Section    : ZBB

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int main(void)
{
    // You will need this when converting from grams to pounds (lbs)
    const double GRAMS_IN_LBS = 453.5924;
    char coffee_type_1, coffee_type_2, coffee_type_3;
    int b_1, b_2, b_3, daily_serve_1, daily_serve_2;
    char creamInput_1, creamInput_2, creamInput_3;
    char strengthOfCoffee_1, strengthOfCoffee_2;
    char cream_1, cream_2;


    printf("Take a Break - Coffee Shop\n"
        "==========================\n\n");

    printf("Enter the coffee product information being sold today...\n\n");

    printf("COFFEE-1...\n");
    printf("Type ([L]ight,[M]edium,[R]ich): ");
    scanf("%c%*c", &coffee_type_1);
    printf("Bag weight (g): ");
    scanf("%d%*c", &b_1);
    printf("Best served with cream ([Y]es,[N]o): ");
    scanf("%c%*c", &creamInput_1); 

    printf("\nCOFFEE-2...\n");
    printf("Type ([L]ight,[M]edium,[R]ich): ");
    scanf("%c%*c", &coffee_type_2);
    printf("Bag weight (g): ");
    scanf("%d%*c", &b_2);
    printf("Best served with cream ([Y]es,[N]o): ");
    scanf("%c%*c", &creamInput_2);

    printf("\nCOFFEE-3...\n");
    printf("Type ([L]ight,[M]edium,[R]ich): ");
    scanf("%c%*c", &coffee_type_3); 
    printf("Bag weight (g): ");
    scanf("%d%*c", &b_3);
    printf("Best served with cream ([Y]es,[N]o): ");
    scanf("%c%*c", &creamInput_3);

    printf("\n");
    printf("---+------------------------+---------------+-------+\n");
    printf("   |    Coffee              |   Packaged    | Best  |\n");
    printf("   |     Type               |  Bag Weight   | Served|\n");
    printf("   +------------------------+---------------+ With  |\n");
    printf("ID | Light | Medium | Rich  |  (G) | Lbs    | Cream |\n");
    printf("---+------------------------+---------------+-------|\n");
    printf(" 1 |   %d   |   %d    |   %d   | %4d | %6.3lf |   %d   |\n",coffee_type_1 == 'l' || coffee_type_1 == 'L', coffee_type_1 == 'm' || coffee_type_1 == 'M', coffee_type_1 == 'r' || coffee_type_1 == 'R', b_1, b_1 / GRAMS_IN_LBS, creamInput_1 == 'y' || creamInput_1 == 'Y');
    printf(" 2 |   %d   |   %d    |   %d   | %4d | %6.3lf |   %d   |\n",coffee_type_2 == 'l' || coffee_type_2 == 'L', coffee_type_2 == 'm' || coffee_type_2 == 'M', coffee_type_2 == 'r' || coffee_type_2 == 'R', b_2, b_2 / GRAMS_IN_LBS, creamInput_2 == 'y' || creamInput_2 == 'Y');
    printf(" 3 |   %d   |   %d    |   %d   | %4d | %6.3lf |   %d   |\n",coffee_type_3 == 'l' || coffee_type_3 == 'L', coffee_type_3 == 'm' || coffee_type_3 == 'M', coffee_type_3 == 'r' || coffee_type_3 == 'R', b_3, b_3 / GRAMS_IN_LBS, creamInput_3 == 'y' || creamInput_3 == 'Y');

    printf("\nEnter how you like your coffee...\n\n");
    printf("Coffee strength ([L]ight, [M]edium, [R]ich): ");
    scanf("%c%*c", &strengthOfCoffee_1);
    printf("Do you like your coffee with cream ([Y]es,[N]o): ");
    scanf("%c%*c", &cream_1);
    printf("Typical number of daily servings: ");
    scanf("%d%*c", &daily_serve_1); 
    printf("\nThe below table shows how your preferences align to the available products:\n\n");
    
    printf("--------------------+-------------+-------+\n");
    printf("  |     Coffee      |  Packaged   | With  |\n");
    printf("ID|      Type       | Bag Weight  | Cream |\n");
    printf("--+-----------------+-------------+-------+\n");
    printf(" 1|       %d         |      %d      |   %d   |\n", coffee_type_1 != strengthOfCoffee_1, daily_serve_1 <=4 && daily_serve_1 >=1, cream_1 == creamInput_1);
    printf(" 2|       %d         |      %d      |   %d   |\n", coffee_type_2 == strengthOfCoffee_1, daily_serve_1 <= 9 && daily_serve_1 >= 5, cream_1 == creamInput_2);
    printf(" 3|       %d         |      %d      |   %d   |\n", coffee_type_3 == strengthOfCoffee_1, daily_serve_1 >= 10, cream_1 == creamInput_3);

    printf("\nEnter how you like your coffee...\n\n");
    printf("Coffee strength ([L]ight, [M]edium, [R]ich): ");
    scanf("%c%*c", &strengthOfCoffee_2);
    printf("Do you like your coffee with cream ([Y]es,[N]o): ");
    scanf("%c%*c", &cream_2);
    printf("Typical number of daily servings: ");
    scanf("%d%*c", &daily_serve_2);
    printf("\nThe below table shows how your preferences align to the available products:\n\n");

    printf("--------------------+-------------+-------+\n"); 
    printf("  |     Coffee      |  Packaged   | With  |\n"); 
    printf("ID|      Type       | Bag Weight  | Cream |\n"); 
    printf("--+-----------------+-------------+-------+\n"); 
    printf(" 1|       %d         |      %d      |   %d   |\n", coffee_type_1 == strengthOfCoffee_2 , daily_serve_2 <= 1 && daily_serve_2 >= 4, cream_2 == creamInput_1); 
    printf(" 2|       %d         |      %d      |   %d   |\n", coffee_type_2 == strengthOfCoffee_2, daily_serve_2 <= 9 && daily_serve_2 >= 5, cream_2 != creamInput_2);
    printf(" 3|       %d         |      %d      |   %d   |\n\n", coffee_type_3 != strengthOfCoffee_2,  daily_serve_2 >= 10, cream_2 == creamInput_3);  

    printf("Hope you found a product that suits your likes!\n");
    return 0;
}


/*

Provided formatting parts for printf statements:

As described in step-7
======================
printf(" 1 |   %d   |   %d    |   %d   | %4d | %6.3lf |   %d   |\n",

As described in step-10
=======================
printf(" 1|       %d         |      %d      |   %d   |\n",

*/