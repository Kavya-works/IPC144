/*
*****************************************************************************
                          Workshop - #4 (P2)
Full Name  : Kavya Bhavinkumar Shah
Student ID#: 140055229
Email      : kbshah6@myseneca.ca
Section    : ZBB
Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
*****************************************************************************
*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int main(void)
{
    int apples, oranges, pears, tomatoes, cabbages;
    int NumberOfItems, shopping = 1; 

//Round - 1
    printf("Grocery Shopping\n");
    printf("================\n");

    //QuantityOfApples
    printf("How many APPLES do you need? : ");
    scanf("%d", &apples);
    while (apples < 0) {
        printf("ERROR: Value must be 0 or more.\n");
        printf("How many APPLES do you need? : ");
        scanf("%d", &apples);
    }
    printf("\n");

    //QuantityOfOranges
    printf("How many ORANGES do you need? : ");
    scanf("%d", &oranges);
    while (oranges < 0) {
        printf("ERROR: Value must be 0 or more.\n");
        printf("How many ORANGES do you need? : ");
        scanf("%d", &oranges);
    }
    printf("\n");

    //QuantityOfPears
    printf("How many PEARS do you need? : ");
    scanf("%d", &pears);
    while (pears < 0) {
        printf("ERROR: Value must be 0 or more.\n");
        printf("How many PEARS do you need? : ");
        scanf("%d", &pears);
    }
    printf("\n");

    //QuantityOfTomatoes
    printf("How many TOMATOES do you need? : ");
    scanf("%d", &tomatoes);
    while (tomatoes < 0) {
        printf("ERROR: Value must be 0 or more.\n");
        printf("How many TOMATOES do you need? : ");
        scanf("%d", &tomatoes);
    }
    printf("\n"); 

    //QuantityOfCabbages
    printf("How many CABBAGES do you need? : ");
    scanf("%d", &cabbages);
    while (cabbages < 0) {
        printf("ERROR: Value must be 0 or more.\n");
        printf("How many CABBAGES do you need? : ");
        scanf("%d", &cabbages);
    }
    printf("\n"); 

//PickProducts
    printf("--------------------------\n"); 
    printf("Time to pick the products!\n"); 
    printf("--------------------------\n\n"); 
  
    //APPLES
    if (apples > 0) {
        do {
            printf("Pick some APPLES... how many did you pick? : ");
            scanf("%d", &NumberOfItems);

            while (NumberOfItems < 1) {
                printf("ERROR: You must pick at least 1!\n");
                printf("Pick some APPLES... how many did you pick? : "); 
                scanf("%d", &NumberOfItems); 
            } 
             
            if (NumberOfItems <= apples) {  
                apples -= NumberOfItems;  
                if (apples == 0) {  
                    printf("Great, that's the apples done!\n");  
                } 
                else { 
                    printf("Looks like we still need some APPLES...\n"); 
                } 
            } 
            else { 
                printf("You picked too many... only %d more APPLE(S) are needed.\n", apples);
            }
        } while (apples > 0);
    }
    else {
        printf("Your tasks are done for today - enjoy your free time!\n");
    }
    
    printf("\n");

    //PEARS
    if (pears > 0) { 
        do {
            printf("Pick some PEARS... how many did you pick? : ");
            scanf("%d", &NumberOfItems);

            while (NumberOfItems < 1) {
                printf("ERROR: You must pick at least 1!\n");
                printf("Pick some PEARS... how many did you pick? : ");
                scanf("%d", &NumberOfItems);
            }

            if (NumberOfItems <= pears) {
                pears -= NumberOfItems; 
                if (pears == 0) {
                    printf("Great, that's the pears done!\n");
                }
                else {
                    printf("Looks like we still need some PEARS...\n");
                }
            }
            else {
                printf("You picked too many... only %d more PEAR(S) are needed.\n", pears); 
            }
        } while (pears > 0); 
    }
    else {
        printf("Your tasks are done for today - enjoy your free time!\n"); 
    }

    printf("\n");

    //CABBAGES
    if (cabbages > 0) {
        do {
            printf("Pick some CABBAGES... how many did you pick? : ");
            scanf("%d", &NumberOfItems);

            while (NumberOfItems < 1) {
                printf("ERROR: You must pick at least 1!\n");
                printf("Pick some CABBAGES... how many did you pick? : ");
                scanf("%d", &NumberOfItems);
            }

            if (NumberOfItems <= cabbages) { 
                cabbages -= NumberOfItems; 
                if (cabbages == 0) { 
                    printf("Great, that's the cabbages done!\n");
                }
                else {
                    printf("Looks like we still need some CABBAGES...\n");
                }
            }
            else {
                printf("You picked too many... only %d more CABBAGE(S) are needed.\n", cabbages);
            }
        } while (cabbages > 0); 
    }
    else {
        printf("Your tasks are done for today - enjoy your free time!\n"); 
    }

    printf("\nAll the items are picked!");
    printf("\n\n");
    printf("Do another shopping? (0=NO): ");
    scanf("%d", &shopping);
    printf("\n");

// Round - 2
    do {
        printf("Grocery Shopping\n");
        printf("================\n");

        printf("How many APPLES do you need? : ");
        scanf("%d", &apples);
        printf("\n");

        printf("How many ORANGES do you need? : ");
        scanf("%d", &oranges);
        printf("\n"); 

        printf("How many PEARS do you need? : ");
        scanf("%d", &pears);
        printf("\n"); 

        printf("How many TOMATOES do you need? : ");
        scanf("%d", &tomatoes);
        printf("\n");

        printf("How many CABBAGES do you need? : ");
        scanf("%d", &cabbages);
        printf("\n"); 

        printf("--------------------------\n");
        printf("Time to pick the products!\n");
        printf("--------------------------\n\n");

        //ORANGES
        while (oranges > 0) {
            printf("Pick some ORANGES... how many did you pick? : ");
            scanf("%d", &NumberOfItems);

            if (NumberOfItems < 1) {
                printf("ERROR: You must pick at least 1!\n");
                continue;
            }

            if (NumberOfItems > oranges) {
                printf("You picked too many... only %d more ORANGE(S) are needed.\n", oranges);
                continue;
            }

            oranges -= NumberOfItems;

            if (oranges == 0) {
                printf("Great, that's the oranges done!\n");
            }
            else {
                printf("Looks like we still need some ORANGES...\n");
            }
        }

        printf("\n"); 

        //TOMATOES
        while (tomatoes > 0) {
            printf("Pick some TOMATOES... how many did you pick? : ");
            scanf("%d", &NumberOfItems);

            if (NumberOfItems < 1) {
                printf("ERROR: You must pick at least 1!\n");
                continue;
            }

            if (NumberOfItems > tomatoes) {
                printf("You picked too many... only %d more TOMATO(ES) are needed.\n", tomatoes);
                continue;
            }

            tomatoes -= NumberOfItems;

            if (tomatoes == 0) {
                printf("Great, that's the tomatoes done!\n");
            }
            else {
                printf("Looks like we still need some TOMATOES...\n");
            }
        }
        printf("\n");  
        printf("All the items are picked!\n");
        printf("\n"); 

        printf("Do another shopping? (0=NO): ");
        scanf("%d", &shopping);
        printf("\n");
        printf("Your tasks are done for today - enjoy your free time!\n");

    } while (shopping != 0);

    return 0;
}