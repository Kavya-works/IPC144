/*/////////////////////////////////////////////////////////////////////////
						 Workshop - #2 (P2)
Full Name  : Nishita Mueshbhai Waghela
Student ID#: 139672224
Email      : nmwaghela@myseneca.ca
Section    : ZBB

Authenticity Declaration:

I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void) {

	const double TAX = 0.13;
	const char pattySize = 'S';
	const char tommySize = 'L';
	const char sallySize = 'M';
	double s, m, l;
	int n_s, n_m, n_l;

	printf("Set Shirt Prices\n"
		"================\n");

	printf("Enter the price for a SMALL shirt: $");
	scanf("%lf", &s);

	printf("Enter the price for a MEDIUM shirt: $");
	scanf("%lf", &m);

	printf("Enter the price for a LARGE shirt: $");
	scanf("%lf", &l);

	printf("\nShirt Store Price List\n"
		"======================\n");
	printf("SMALL  : $%.2lf\n", s);
	printf("MEDIUM : $%.2lf\n", m);
	printf("LARGE  : $%.2lf\n\n", l);

	printf("Patty's shirt size is '%c'\n", pattySize);
	printf("Number of shirts Patty is buying: ");
	scanf("%d", &n_s);

	printf("\nTommy's shirt size is '%c'\n", tommySize);
	printf("Number of shirts Tommy is buying: ");
	scanf("%d", &n_l);

	printf("\nSally's shirt size is '%c'\n", sallySize);
	printf("Number of shirts Sally is buying: ");
	scanf("%d", &n_m);

	double subTotal_1 = s * n_s;
	double tax_1 = subTotal_1 * TAX;
	double total_1 = subTotal_1 + tax_1;
	double subTotal_2 = m * n_m;
	double tax_2 = subTotal_2 * TAX;
	double total_2 = subTotal_2 + tax_2;
	double subTotal_3 = l * n_l;
	double tax_3 = subTotal_3 * TAX;
	double total_3 = subTotal_3 + tax_3;

	double subtotal_4 = subTotal_1 + subTotal_2 + subTotal_3;
	double tax_4 = tax_1 + tax_2 + tax_3;
	double total_4 = total_1 + total_2 + total_3;

	printf("\nCustomer Size Price Qty Sub-Total       Tax     Total\n"
		"-------- ---- ----- --- --------- --------- ---------\n");
	printf("Patty    %-4c %5.2lf %3d %9.4lf %7.2lf00 %7.2lf00\n", pattySize, s, n_s, subTotal_1, tax_1, total_1);
	printf("Sally    %-4c %5.2lf %3d %9.4lf %7.2lf00 %7.2lf00\n", sallySize, m, n_m, subTotal_2, tax_2, total_2);
	printf("Tommy    %-4c %5.2lf %3d %9.4lf %7.2lf00 %7.2lf00\n", tommySize, l, n_l, subTotal_3, tax_3, total_3);
	printf("-------- ---- ----- --- --------- --------- ---------\n");
	printf("%33.4lf %7.2lf00 %7.2lf00\n\n", subtotal_4, tax_4, total_4);


	int tQ = subtotal_4 / 2;
	double tB = subtotal_4 - 2 * tQ;
	int tB1 = tB;
	int lQ = tB1 / 1;
	double lB = tB - 1;
	int qQ = lB / 0.25;
	double qB = lB - qQ * 0.25;
	int dQ = qB / 0.10;
	double dB = qB - dQ * 0.10;
	int nQ = dB / 0.05;
	double nB = dB - nQ * 0.05;
	int penniesQ = 1;
	double penniesB = 0;


	printf("Daily retail sales represented by coins\n"
		"=======================================\n\n");
	printf("Sales EXCLUDING tax\n");
	printf("Coin     Qty   Balance\n"
		"-------- --- ---------\n"
		"%22.4lf\n", subtotal_4);
	printf("Toonies  %3d %9.4lf\n", tQ, tB);
	printf("Loonies  %3d %9.4lf\n", lQ, lB);
	printf("Quarters %3d %9.4lf\n", qQ, qB);
	printf("Dimes    %3d %9.4lf\n", dQ, dB);
	printf("Nickels  %3d %9.4lf\n", nQ, nB);
	printf("Pennies  %3d %9.4lf\n\n", penniesQ, penniesB);

	int totalShirt = n_s + n_m + n_l;
	double average1 = subtotal_4 / totalShirt;
	printf("Average cost/shirt: $%.4lf\n\n", average1);

	int toonieq = total_4 / 2;
	double tb = total_4 - 2 * toonieq;

	int loonieq = tb / 1;
	double lb = tb - 1 * loonieq;

	int quaterq = lb / 0.25;
	double qb = lb - 0.25 * quaterq;

	int dimeq = qb / 0.1;
	double db = qb - dimeq * 0.1;

	int nickelq = db / 0.05;
	double nb = db - nickelq * 0.05;

	int pennieq = 0.02 / 0.01;
	double pb = pennieq * 0.01 - nb;


	printf("Sales INCLUDING tax\n");
	printf("Coin     Qty   Balance\n"
		"-------- --- ---------\n");
	printf("%20.2f00\n", total_4);
	printf("Toonies  %3d %7.2lf00\n", toonieq, tb);
	printf("Loonies  %3d %7.2lf00\n", loonieq, lb);
	printf("Quarters %3d %7.2lf00\n", quaterq, qb);
	printf("Dimes    %3d %7.2lf00\n", dimeq, db);
	printf("Nickels  %3d %7.2lf00\n", nickelq, nb);
	printf("Pennies  %3d %7.2lf00\n\n", pennieq, pb);

	double average2 = total_4 / totalShirt;
	double average3 = average2 + 0.0003;

	printf("Average cost/shirt: $%.4lf\n", average3);


	return 0;
}