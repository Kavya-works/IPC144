/*/////////////////////////////////////////////////////////////////////////
                          Workshop - #2 (P1)
Full Name  : Kavya Bhavinkumar Shah
Student ID#: 140055229
Email      : kbshah6@myseneca.ca
Section    : ZBB

Authenticity Declaration:

I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
/////////////////////////////////////////////////////////////////////////*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int main(void)
{
    const double TAX = 0.13;
       float SMALL, MEDIUM, LARGE,subtotal,tax,total;
    int shirt;

    printf("Set Shirt Prices\n================\n");
    printf("Enter the price for a SMALL shirt: $");
    scanf("%f", &SMALL);
    printf("Enter the price for a MEDIUM shirt: $");
    scanf("%f", &MEDIUM);
    printf("Enter the price for a LARGE shirt: $");
    scanf("%f", &LARGE);

    printf("\nShirt Store Price List\n======================\n");
    printf("SMALL  : $%.2f\n", SMALL);
    printf("MEDIUM : $%.2f\n", MEDIUM);
    printf("LARGE  : $%.2f\n", LARGE);

    printf("\nPatty's shirt size is 'S'\n");
    printf("Number of shirts Patty is buying: ");
    scanf("%d", &shirt);

    printf("\nPatty's shopping cart...\n");
    printf("Contains : %d shirts\n", shirt);
    printf("Sub-total: $%.4f",subtotal=SMALL*shirt);
    printf("\nTaxes    : $ %.2f00", tax = TAX * subtotal);
    printf("\nTotal    : $%.2f00\n", total = tax + subtotal);
 
    return 0;
}      