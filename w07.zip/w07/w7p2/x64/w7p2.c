/******************************************************************************
<assessment name example : Workshop - #7 (Part - 2)>
Full Name : Kavya Bhavinkumar Shah
Student ID# : 140055229
	Email : kbshah6@myseneca.ca
	Section : ZBB
	Authenticity Declaration :
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider.This submitted
piece of work is entirely of my own creation.
* *****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

//A structure for player information
struct PlayerInfo {
	char symbol;
	int lives;
	int treasure_count[70];
};

//A structure for game information
struct GameInfo {
	int path_length;
	int max_moves;
};

struct Position {
	int bombs[70];
	int treasure[70];
};

int main() {

	struct PlayerInfo player;
	struct GameInfo game;
	struct Position placement;

	printf("================================\n");
	printf("         Treasure Hunt!\n");
	printf("================================\n\n");


	//Player Configuration
	printf("PLAYER Configuration\n");
	printf("--------------------\n");

	//PlayerInfo - Symbol
	printf("Enter a single character to represent the player: ");
	scanf("%c%*c", &player.symbol);

	//PlayerInfo - Lives
	do {
		printf("Set the number of lives: ");
		scanf("%d%*c", &player.lives);
		if (player.lives < 1 || player.lives > 10)
			printf("     Must be between 1 and 10!\n");
	} while (player.lives < 1 || player.lives > 10);
	printf("Player configuration set-up is complete\n\n");


	//Game Configuration
	printf("GAME Configuration\n");
	printf("------------------\n");

	//GameInfo - Path Length
	do {
		printf("Set the path length (a multiple of 5 between 10-70): ");
		scanf("%d%*c", &game.path_length);
		if (game.path_length % 5 || game.path_length < 10 || game.path_length > 70)
			printf("     Must be a multiple of 5 and between 10-70!!!\n");
	} while (game.path_length % 5 || game.path_length < 10 || game.path_length > 70);

	//GameInfo - Max Moves 
	do
	{
		printf("Set the limit for number of moves allowed: ");
		scanf("%d%*c", &game.max_moves);
		if (game.max_moves <= 2 || game.max_moves >= 15)
			printf("    Value must be between 3 and 15\n");
	} while (game.max_moves <= 2 || game.max_moves >= 15);


	//BOMB Placement 
	printf("\nBOMB Placement\n");
	printf("--------------\n");
	printf("Enter the bomb positions in sets of 5 where a value\n");
	printf("of 1=BOMB, and 0=NO BOMB. Space-delimit your input.\n");
	printf("(Example: 1 0 0 1 1) NOTE: there are %d to set!\n", game.path_length);

	int i, j;
	for (i = 0; i < game.path_length; i += 5) {
		printf("   Positions [%2d-%2d]: ", i + 1, i + 5);

		for (j = 0; j < 5; j++) {
			scanf("%d%*c", &placement.bombs[i + j]);
		}
	}
	printf("BOMB placement set\n");

	//Treasure Placement
	printf("\nTREASURE Placement\n");
	printf("------------------\n");
	printf("Enter the treasure placements in sets of 5 where a value\n");
	printf("of 1=TREASURE, and 0=NO TREASURE. Space-delimit your input.\n");
	printf("(Example: 1 0 0 1 1) NOTE: there are %d to set!\n", game.path_length);

	int m, n;
	for (m = 0; m < game.path_length; m += 5) {
		printf("   Positions [%2d-%2d]: ", m + 1, m + 5);

		for (n = 0; n < 5; n++) {
			scanf("%d%*c", &placement.treasure[m + n]);
		}
	}
	printf("TREASURE placement set\n\n");

	printf("GAME configuration set-up is complete...\n\n");
	printf("------------------------------------\n");
	printf("TREASURE HUNT Configuration Settings\n");
	printf("------------------------------------\n");

	//About - Player 
	printf("Player:\n");
	printf("   Symbol     : %c\n", player.symbol);
	printf("   Lives      : %d\n", player.lives);
	printf("   Treasure   : [ready for gameplay]\n");
	printf("   History    : [ready for gameplay]\n\n");

	//About - Game
	printf("Game:\n");
	printf("   Path Length: %d\n", game.path_length);
	printf("   Bombs      : ");
	for (i = 0; i < game.path_length; i++) {
		printf("%d", placement.bombs[i]);
	}
	printf("\n");

	//About - Treasure
	printf("   Treasure   : ");
	for (i = 0; i < game.path_length; i++) {
		printf("%d", placement.treasure[i]);
	}
	printf("\n\n");
	printf("====================================\n");
	printf("~ Get ready to play TREASURE HUNT! ~\n");
	printf("====================================\n\n");

	printf("  ");
	for (i = 0; i < game.path_length; i++) {
		printf("-");
	}
	printf("\n");


	//Range - Scale
	j = 0;
	printf("  ");
	for (i = 1; i <= game.path_length; i++) {


		if (i % 10) {
			printf("|");
		}
		else {
			printf("%d", ++j);
		}

	}
	printf("\n");
	printf("  ");
	for (j = 0; j < game.path_length; j += 10) {

		printf("1234567890");


	}
	printf("\n");

	i = 0;
	int next_moves, number_of_treasure = 0;

	//Lives Left - Treasure - Moves remanining
	printf("+---------------------------------------------------+\n");
	printf("  Lives: % 2d | Treasures : % 2d | Moves Remaining : % 2d\n", player.lives, number_of_treasure, game.max_moves);
	printf("+---------------------------------------------------+\n");

	do {
		do {
			printf("Next Move [1-20]: ");
			scanf("%d", &next_moves);

			if (next_moves <= 0 || next_moves >= 21) {
				printf("  Out of Range!!!\n");
			}
		} while (next_moves <= 0 || next_moves >= 21);

		if (player.treasure_count[next_moves - 1] == 1) {
			printf("\n===============> Dope! You've been here before!\n");
		}
		else if (placement.treasure[next_moves - 1] == 1 && placement.bombs[next_moves - 1] == 1) {
			printf("\n===============> [&] !!! BOOOOOM !!! [&]\n"
				"===============> [&] $$$ Life Insurance Payout!!![&]\n");
			player.lives -= 1;
			number_of_treasure += 1;
			game.max_moves -= 1;
		}
		else if (placement.bombs[next_moves - 1] == 1) {
			printf("\n===============> [!] !!! BOOOOOM !!! [!]\n\n");
			player.lives -= 1;
			game.max_moves -= 1;

			if (player.lives == 0) {
				printf("No more LIVES remaining!\n");
			}
		}
		else if (placement.treasure[next_moves - 1] == 1) {
			printf("\n===============> [$] $$$ Found Treasure! $$$ [$]\n");
			number_of_treasure += 1;
			game.max_moves -= 1;
		}
		else {
			printf("\n===============> [.] ...Nothing found here... [.]\n");
			game.max_moves -= 1;
		}

		printf("\n");
		printf("  ");
		for (i = 0; i < game.path_length; i++) {
			if (next_moves == i + 1) {
				printf("%c", player.symbol);
			}
			else {
				printf(" ");
			}
		}

		printf("\n");
		printf("  ");
		player.treasure_count[next_moves - 1] = 1;

		for (i = 0; i < game.path_length; i++) {

			if (player.treasure_count[i] == 1 && placement.bombs[i] == 1 && placement.treasure[i] == 1) {
				printf("&");

			}
			else if (player.treasure_count[i] == 1 && placement.bombs[i] == 1) {
				printf("!");

			}
			else if (player.treasure_count[i] == 1 && placement.treasure[i] == 1) {
				printf("$");

			}
			else if (player.treasure_count[i] == 1) {
				printf(".");
			}
			else {
				printf("-");
			}

		}

		printf("\n");

		
		j = 0;
		printf("  ");
		for (i = 1; i <= game.path_length; i++) {


			if (i % 10) {
				printf("|");
			}
			else {
				printf("%d", ++j);
			}

		}

		printf("\n");
		printf("  ");

		for (j = 0; j < game.path_length; j += 10) {

			printf("1234567890");

		}

		printf("\n");




		printf("+---------------------------------------------------+\n");

		printf("  Lives: %2d  | Treasures: %2d  | Moves Remaining: %2d \n", player.lives, number_of_treasure, game.max_moves);

		printf("+---------------------------------------------------+\n");

	} while (player.lives != 0);

	printf("\n##################\n"
		"#   Game over!   #\n"
		"##################\n");

	printf("\nYou should play again and try to beat your score!\n");

	return 0;

}
